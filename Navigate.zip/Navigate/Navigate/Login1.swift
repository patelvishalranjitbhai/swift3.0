//
//  ViewController.swift
//  Navigate
//
//  Created by BL@CK on 1/4/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class Login1: UIViewController
{

    @IBOutlet weak var HomeImg: UIImageView!
    @IBOutlet weak var Txtemail: UITextField!
    @IBOutlet weak var Txtpwd: UITextField!
    override func viewDidLoad()
        
        {
   
        super.viewDidLoad()
            
//            var obj : validation = validation()
//            obj.txt(mainView: self.view)
            
            
            self.title = "Log In"
            Txtpwd.isSecureTextEntry = true
            Txtemail.keyboardType = UIKeyboardType.emailAddress
            HomeImg.image = UIImage(named: "Hom.png")
            
            
            self.view.backgroundColor = UIColor(patternImage: UIImage(named: "img12.jpeg")!)
            
            Txtemail.attributedPlaceholder = NSAttributedString(string: "Enter Your Email",attributes: [NSForegroundColorAttributeName: UIColor.darkGray])
            Txtpwd.attributedPlaceholder = NSAttributedString(string: "Enter Your Password",attributes: [NSForegroundColorAttributeName: UIColor.darkGray])
            
    }

    
    
    @IBAction func LogIn(_ sender: UIButton)
    
{
        let emailco = Txtemail.text
        let pwdco = Txtpwd.text
        let Emailaddvalid = isValidEmailAddress(emailAddressString: emailco!)
    
    
    
        let setmail = UserDefaults.standard.string(forKey: "UserEmail")
        let setpwd = UserDefaults.standard.string(forKey: "UserPwd")
    
        if setmail == emailco && setpwd == pwdco
    
        {
            let co : option3 = self.storyboard?.instantiateViewController(withIdentifier: "option3")
            as! option3
            self.navigationController?.pushViewController(co, animated: true)
            
        }
    
    
        if ((emailco?.isEmpty)! || (pwdco?.isEmpty)!)
        
            {
                displayalrt(msgfordisplay: "All Fields Are Required")
                
                return
        
            }
 
        else
      
        {
            
            if Emailaddvalid
            {
                print("email is valid")
                
            }
            else
            {
                print("Email is not valid")
                displayalrt(msgfordisplay: "Email is not valid")
                
            }
            
        }
    }
    
    
    func isValidEmailAddress(emailAddressString: String) -> Bool
    {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: emailAddressString)
        
    }
    
    func displayalrt(msgfordisplay: String)
    {
        
        let myAlert = UIAlertController(title: "Alert" , message: msgfordisplay , preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default)
        {
            (action: UIAlertAction!)in
            
            //print("Ok Button Tapped")
        }
        
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
        
        }
    
    @IBAction func SignUp(_ sender: UIButton)
        
    {
        

        let viewCtrl2 : Register2 = self.storyboard?.instantiateViewController(withIdentifier: "Register2") as! Register2
        self.navigationController?.pushViewController(viewCtrl2, animated: true)
        
        
    }

}



