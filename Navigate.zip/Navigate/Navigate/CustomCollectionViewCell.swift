//
//  CustomCollectionViewCell.swift
//  Navigate
//
//  Created by agile on 20/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell
{
    
    @IBOutlet weak var img: UIImageView!
}
