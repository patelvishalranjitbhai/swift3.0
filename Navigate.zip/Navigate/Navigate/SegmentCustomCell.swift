//
//  SegmentCustomCell.swift
//  Navigate
//
//  Created by agile on 03/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class SegmentCustomCell: UICollectionViewCell
{
    
    @IBOutlet weak var collimgview: UIImageView!
}
