//
//  ViewController2.swift
//  Navigate
//
//  Created by BL@CK on 1/4/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class Register2: UIViewController,UITextFieldDelegate
{

    @IBOutlet weak var Txtname: UITextField!
    @IBOutlet weak var Txtsurname: UITextField!
    @IBOutlet weak var Txtemail: UITextField!
    @IBOutlet weak var Txtpwd: UITextField!
    @IBOutlet weak var Txtcpwd: UITextField!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.title = "Register"
    
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "img12.jpeg")!)
       
        


        // Do any additional setup after loading the view.
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        
        if (string == " ")
        {
            return false
        }
      
        if textField.tag == 4 && textField.tag == 5
        {
            
            
            guard let text = textField.text else { return true }
            let newLength = text.characters.count + string.characters.count - range.length
            
            let aSet = NSCharacterSet(charactersIn:"qwertyuioplkjhgfdsazxcvbnm").inverted
            let Cmp = string.components(separatedBy: aSet)
            let numberFiltered = Cmp.joined(separator: "")
            
            
            return newLength <= 10 && string == numberFiltered
            
        }
//        else if textField.tag == 2 || textField.tag == 1 || textField.tag == 3 || textField.tag == 4 || textField.tag == 5
//        {
//            if (string == " ")
//            {
//                return false
//            }
//            return true
//            
//        }
        
        return true
        
    }

    
    
    @IBAction func RegTap(_ sender: UIButton)
    {
        let Name = Txtname.text
        let Surname = Txtsurname.text
        let Email = Txtemail.text
        let Pwd = Txtpwd.text
        let Cpwd =  Txtcpwd.text
        let Emailaddvalid = isValidEmailAddress(emailAddressString: Email!)
        
        
      //validation
        
       
        
        // for empty fields
        
        if ((Name?.isEmpty)! || (Surname?.isEmpty)! || (Email?.isEmpty)! || (Pwd?.isEmpty)! || (Cpwd?.isEmpty)!)
        {
            
       displayalrt(msgfordisplay: "All Fields Are Required")
            
            return
            
        }

        else
            
        {
            
            if Emailaddvalid
            {
                print("email is valid")
                
            }
            else
            {
                print("Email is not valid")
                displayalrt(msgfordisplay: "Email is not valid")
                
            }
            
        }
      
        
        UserDefaults.standard.set(Email, forKey: "UserEmail")
        UserDefaults.standard.set(Pwd, forKey: "UserPwd")
        UserDefaults.standard.synchronize()
    }
    
    
    func isValidEmailAddress(emailAddressString: String) -> Bool
    {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: emailAddressString)
    }
    
    func displayalrt(msgfordisplay: String)
    {
        
        let myAlert = UIAlertController(title: "Alert" , message: msgfordisplay , preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default)
        {
            (action: UIAlertAction!)in
            
            //print("Ok Button Tapped")
        }
        
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
        
    }
    

    
    
    @IBAction func Clear(_ sender: UIButton)
    {
        
        
        
        let viewCtrl4 : option3 = self.storyboard?.instantiateViewController(withIdentifier: "option3") as! option3
        self.navigationController?.pushViewController(viewCtrl4, animated: true)
  
        
    }
    
    @IBAction func SignIn(_ sender: UIButton)
    {
        
        //self.navigationController?.popViewController(animated: true)
    
    }
    
    @IBAction func fblogin(_ sender: UIButton)
    {
        let fblg : LoginViaFb10 = self.storyboard?.instantiateViewController(withIdentifier: "LoginViaFb10")
        as! LoginViaFb10
        
        self.navigationController?.pushViewController(fblg, animated: true)
    }

}
