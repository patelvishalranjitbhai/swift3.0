//
//  validation.swift
//  Navigate
//
//  Created by agile on 08/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class validation: NSObject
{
    
    func txt(mainView : UIView)
    {
        
        var txt1 : UITextField = UITextField()
        txt1.frame = CGRect(x: 10, y: 10, width: 150, height: 40)
        txt1.backgroundColor = UIColor.red
        mainView.addSubview(txt1)
    }
    
 
    
    
    func displayalrt(msgfordisplay: String)
    {
        
        let myAlert = UIAlertController(title: "Alert" , message: msgfordisplay , preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default)
        {
            (action: UIAlertAction!)in

        }
        
        myAlert.addAction(okAction)
        

        
    }


}
