//
//  option3.swift
//  Navigate
//
//  Created by BL@CK on 1/12/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit


class option3: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    let cls = "MyCell"
    
    @IBOutlet weak var tblview: UITableView!
    
    var selind : [Int] = [Int()]
    
    var ARint = ["Nike","Puma","Vans","Jordan","Acisc","Adidas","Lee","Crocs"]

    
    var Aint : [UIImage] = [UIImage.init(named: "Nike.png")!,UIImage.init(named: "Puma.png")!,UIImage.init(named: "Vans.png")!,UIImage.init(named: "Jordan.png")!,UIImage.init(named: "Acisc.png")!,UIImage.init(named: "Adidas.png")!, UIImage.init(named: "Lee.png")!,UIImage.init(named: "Crocs.png")!]

    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
   
        let dct : [String : AnyObject] = ["Brand Name" : ARint as AnyObject]
        
        
        for (key,value) in dct
        {
            for value2 in ARint
            {
                print("\(key) is \(value2)")
            }
        }
        
        tblview.register(UINib.init(nibName: cls, bundle: nil), forCellReuseIdentifier: cls)
        
        // Do any additional setup after loading the view.
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
        {
            return ARint.count
        }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let clone = tableView.dequeueReusableCell(withIdentifier: cls) as! MyCell
        
        clone.Txtlbl.text = ARint[indexPath.row]
            
        clone.silico.image  = Aint[indexPath.row]
   
        clone.BtnTap.addTarget(self, action: #selector(option3.ClickButton(sender:)), for: .valueChanged)
        
        clone.BtnTap.tag = indexPath.row
        
        return clone
    }
    
    
    func ClickButton(sender:UISwitch)
    {
        let acell = tblview.cellForRow(at: IndexPath(row: sender.tag, section: 0)) as! MyCell
        
        acell.silico.image = UIImage(named: "img1")
        
    
    }

    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let imageg : nidhu = storyboard?.instantiateViewController(withIdentifier: "nidhu") as! nidhu
       
        imageg.img1 = Aint
        imageg.indo = indexPath.row
        imageg.ddl = ARint
        
        
        self.navigationController?.pushViewController(imageg, animated: true)
    }
    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        }
    
    
    
    @IBAction func NextTap(_ sender: UIButton)
    {
        let pg4 : Content4 = self.storyboard?.instantiateViewController(withIdentifier: "Content4") as! Content4
        
        self.navigationController?.pushViewController(pg4, animated: true)
        
    }

   
}
