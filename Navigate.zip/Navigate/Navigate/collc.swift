//
//  collc.swift
//  Navigate
//
//  Created by BL@CK on 1/16/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class collc: UIViewController, UICollectionViewDelegate ,UICollectionViewDataSource
{

    @IBOutlet weak var colview: UICollectionView!
    
    var topimg : [NSString] = ["img1","img2","img3","img4","img5","img6",]
    var i : Int = Int()
    
    override func viewDidLoad()
    {
        i = 0
        super.viewDidLoad()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return topimg.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let sd = collectionView.dequeueReusableCell(withReuseIdentifier: "coll", for: indexPath as IndexPath)
       // sd.backgroundView?.frame = CGRect(x: 10, y: 0, width: 320, height: 240)
        
        
         if i <= topimg.count - 2
         {
            i += 1
            sd.backgroundColor = UIColor(patternImage: UIImage(named: topimg[i] as String)!)
            
       // sd.backgroundColor = UIColor.brown
        }
        return sd
    }
    

    
    @IBAction func Nxt(_ sender: UIButton)
    {
        let nxt : LoginViaFb10 = self.storyboard?.instantiateViewController(withIdentifier: "LoginViaFb10") as! LoginViaFb10
        self.navigationController?.pushViewController(nxt, animated: true)
    }
}
