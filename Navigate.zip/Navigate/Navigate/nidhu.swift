//
//  nidhu.swift
//  Navigate
//
//  Created by BL@CK on 1/18/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class nidhu: UIViewController {

    
    @IBOutlet weak var Bname: UILabel!
    
    
    @IBOutlet weak var iimm: UIImageView!
    
    
    var img1 : [UIImage] = []
    var indo : Int = Int()
    var ddl : [String] = [String()]
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        iimm.image = img1[indo]
        Bname.text = ddl[indo]
    }

   
    @IBAction func NXT(_ sender: UIButton)
    {
        
    }
   }
