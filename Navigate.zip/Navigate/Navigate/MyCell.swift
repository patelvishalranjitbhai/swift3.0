//
//  MyCell.swift
//  Navigate
//
//  Created by BL@CK on 1/12/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class MyCell: UITableViewCell {

    @IBOutlet weak var Txtlbl: UILabel!
    
    @IBOutlet weak var silico: UIImageView!
    
    @IBOutlet weak var BtnTap: UISwitch!
    
    override func awakeFromNib()
    
    
    {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
  }
