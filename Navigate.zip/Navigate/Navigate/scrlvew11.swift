//
//  scrlvew11.swift
//  Navigate
//
//  Created by agile on 11/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class scrlvew11: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource
{

    @IBOutlet weak var selview: UIScrollView!
    
    @IBOutlet weak var Txtshoe: UITextField!
    
    @IBOutlet weak var imgview: UIImageView!
    
    
    var obj : validation = validation()
    
    var topimg : [NSString] = ["img1","img2","img3","img4","img5","img6",]
    
    
    var Arrimg : [NSString] = ["Adidas","Puma","Jordan","Nike","Levi's",]
    
    
    override func viewDidLoad()
    
    {
        super.viewDidLoad()
        
        
        
        selview.contentSize = CGSize(width: selview.frame.width * 6, height: 166)
        var a : CGFloat = 0
        
        for var i in 0...5
        {
            let imageView : UIImageView = UIImageView()
            imageView.frame = CGRect(x: a, y: 0, width: selview.frame.width, height: 166)
                imageView.image = UIImage(named:topimg[i] as String)
            self.selview.addSubview(imageView)
            a = a + selview.frame.width
            
            selview.isPagingEnabled = true
        }
      
       
        pkr()
        
    }
    
    
    func pkr()
    {
        let pckr : UIPickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        
        pckr.delegate = self
        pckr.dataSource = self
        
        Txtshoe.inputView = pckr
        
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.blackOpaque
        
        toolBar.isTranslucent = true
        
        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        
        toolBar.sizeToFit()
        
        let okbtn = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(scrlvew11.com))
        okbtn.width = 50
        
        let can = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target:self, action: #selector(scrlvew11.com))
        
        can.width = 50
        
        
         let spaceButton1 = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
         let spaceButton2 = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        
        
        let lblTest:UILabel = UILabel();
        lblTest.text = "Select City"
        lblTest.textColor = UIColor.white
        lblTest.frame = CGRect(x: 100, y: 50, width: 250, height: 20)
        lblTest.textAlignment = NSTextAlignment.center

        let titleButton = UIBarButtonItem(customView: lblTest)
        
        toolBar.setItems([can,spaceButton1,titleButton,spaceButton2,okbtn], animated: true)
        
        
        
        toolBar.isUserInteractionEnabled = true
        
        
        Txtshoe.inputAccessoryView = toolBar
        
        
        

    }

    func com()
    
    {
      
        let smg : Gesture13 = self.storyboard?.instantiateViewController(withIdentifier: "Gesture13") as! Gesture13
        
       
        
        Txtshoe.resignFirstResponder()
        
        self.navigationController?.pushViewController(smg, animated: true)
        
        
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Arrimg.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        
        
        
            return Arrimg[row] as? String;
    }
    
    
    
    @IBAction func Nxt(_ sender: UIButton)
    {
        let nxt : Imgpckr12 = self.storyboard?.instantiateViewController(withIdentifier: "Imgpckr12") as! Imgpckr12
        self.navigationController?.pushViewController(nxt, animated: true)
        
        
    }
    
    
    
}
