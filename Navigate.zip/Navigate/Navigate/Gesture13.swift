//
//  Gesture13.swift
//  Navigate
//
//  Created by Mac on 2/16/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class Gesture13: UIViewController

{

    @IBOutlet weak var swipeimg: UIImageView!
    
    @IBOutlet weak var pckrimg: UIImageView!
    
    @IBOutlet weak var datepckr: UITextField!
    
    
     var datePickerView : UIDatePicker!
    
    var topimg : [NSString] = ["img1","img2","img3","img4","img5","img6",]
    var i : Int = Int()
    override func viewDidLoad()
    {
        
        
        i=0;
        
        swipeimg.image = UIImage(named: topimg[i] as String)
        
        super.viewDidLoad()
        
        sag()

      
    }

   
    
    @IBAction func upswipe(_ sender: UISwipeGestureRecognizer)
    {
        self.view.backgroundColor = UIColor.orange
    }

    @IBAction func downswipe(_ sender: UISwipeGestureRecognizer)
    {
        self.view.backgroundColor = UIColor.orange
    }
    
    @IBAction func Left(_ sender: UISwipeGestureRecognizer)
    {
        
        if i <= topimg.count - 2
        {
        print(topimg.count)
        i += 1
        swipeimg.image = UIImage(named: topimg[i] as String)
        self.view.backgroundColor = UIColor.orange
        }
    }
    
    @IBAction func right(_ sender: UISwipeGestureRecognizer)
    {
        if  i >= 1
        {
            
        i -= 1
        swipeimg.image = UIImage(named: topimg[i] as String)
        self.view.backgroundColor = UIColor.orange
        }
    }
    
    func sag ()
    {
        
        
      let datePickerView  = UIDatePicker()
      datePickerView.datePickerMode = UIDatePickerMode.date
        datePickerView.addTarget(self, action: Selector(("due")), for: UIControlEvents.valueChanged)
        
        datepckr.inputView = datePickerView;
        
        let toolBar = UIToolbar()
        
        toolBar.barStyle = UIBarStyle.blackOpaque
        
        toolBar.isTranslucent = true
        
        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        
        toolBar.sizeToFit()
        
        let okbtn = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(Gesture13.com))
        okbtn.width = 50
        
        let can = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target:self, action: #selector(Gesture13.com))
        
        can.width = 50
        
        
        let spaceButton1 = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let spaceButton2 = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        
        
        let lblTest:UILabel = UILabel();
        lblTest.text = "Date"
        lblTest.textColor = UIColor.white
        lblTest.frame = CGRect(x: 100, y: 50, width: 250, height: 20)
        lblTest.textAlignment = NSTextAlignment.center
        
        let titleButton = UIBarButtonItem(customView: lblTest)
        
        toolBar.setItems([can,spaceButton1,titleButton,spaceButton2,okbtn], animated: true)
        
        
        
        toolBar.isUserInteractionEnabled = true
        
        
        datepckr.inputAccessoryView = toolBar


    }
    
    func due(sender: UIDatePicker)
        
        {
            
            let dateFormatter = DateFormatter()
            
            dateFormatter.dateStyle = DateFormatter.Style.long
            
            dateFormatter.timeStyle = DateFormatter.Style.none
            
        self.datepckr.text = dateFormatter.string(from: sender.date)
 
        }
    
    func com()
        
    {
  
        datepckr.resignFirstResponder()
    
    }

    @IBAction func Nxt13(_ sender: UIButton)
    {
        let nxt : collect14 = self.storyboard?.instantiateViewController(withIdentifier: "collect14") as! collect14
        self.navigationController?.pushViewController(nxt, animated: true)
    }
    
    }

