//
//  Imgpckr12.swift
//  Navigate
//
//  Created by agile on 14/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class Imgpckr12: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate
{

    @IBOutlet weak var imgsel: UIImageView!
    
    let imgopkr = UIImagePickerController()
    
    override func viewDidLoad()
    
    {

        
        super.viewDidLoad()

        imgopkr.delegate = self
       
    }
   
    
    @IBAction func selphoto(_ sender: UIButton)
    {
        imgopkr.allowsEditing = true
        imgopkr.sourceType = .photoLibrary
        present(imgopkr, animated: true, completion: nil)
    }
    
     public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject])
    
    {
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage
        {
           
            imgsel.contentMode = .scaleAspectFit
            imgsel.image = pickedImage
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
       self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func Nxt(_ sender: UIButton)
    {
        
        let nxt : Gesture13 = self.storyboard?.instantiateViewController(withIdentifier: "Gesture13") as! Gesture13
        self.navigationController?.pushViewController(nxt, animated: true)
        
        
    }
}
