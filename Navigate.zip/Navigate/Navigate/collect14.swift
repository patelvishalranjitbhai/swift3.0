//
//  collect14.swift
//  Navigate
//
//  Created by agile on 20/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class collect14: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {

    
    @IBOutlet var pgcntrl: UIPageControl!
    
    @IBOutlet weak var clview: UICollectionView!
    
    var topimg : [NSString] = ["img1","img2","img3","img4","img5","img6",]
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        pgcntrl.numberOfPages = topimg.count
        pgcntrl.currentPage = 0
        
        // Do any additional setup after loading the view.
    }

    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return topimg.count
        
    }
        
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        
        
        let sgo = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCollectionViewCell
        sgo.layer.borderColor = UIColor.black.cgColor
        sgo.layer.borderWidth = 1
        sgo.layer.cornerRadius = 8
        sgo.img.image = UIImage(named: topimg[indexPath.row] as String)

        
        return sgo
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        
        let nxt : ViewController15 = storyboard?.instantiateViewController(withIdentifier: "ViewController15") as! ViewController15
  
        nxt.simg = topimg as [String]
        nxt.vos = indexPath.row
        
        
        self.navigationController?.pushViewController(nxt, animated: true)
   
    }
    
    
    func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool
    {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor.black
        print("shouldHighlightItemAt")
        return true
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor.blue
        print("didHighlightItemAt")
    }
    
    
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor.lightGray
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        let centerPoint = CGPoint(x: self.clview.center.x + self.clview.contentOffset.x, y: self.clview.center.y + self.clview.contentOffset.y)
        let centerCellIndexPath = self.clview.indexPathForItem(at: centerPoint)!
        pgcntrl.currentPage = centerCellIndexPath.row
    }
    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func nxt14(_ sender: UIButton)
    {
        let nxt15 : ViewController15 = self.storyboard?.instantiateViewController(withIdentifier: "ViewController15") as! ViewController15
        self.navigationController?.pushViewController(nxt15, animated: true)
    }

   
}
