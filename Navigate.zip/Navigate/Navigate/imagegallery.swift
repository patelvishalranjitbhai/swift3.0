//
//  imagegallery.swift
//  Navigate
//
//  Created by BL@CK on 1/5/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class imagegallery: UIViewController {
    
    @IBOutlet weak var Img: UIImageView!
    
    @IBOutlet weak var actvt: UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Image Views"
        
        actvt.hidesWhenStopped = true
        // Do any additional setup after loading the view.
    }

    @IBAction func start(_ sender: UIButton)
    {
        let Arrimg : [UIImage] = [UIImage.init(named: "airmax.png")!,UIImage.init(named: "pems.png")!, UIImage.init(named: "old.png")!, UIImage.init(named: "jor.png")!, UIImage.init(named: "asc.png")!, UIImage.init(named: "adi.png")!,UIImage.init(named: "lec.png")!]
        
        Img.animationImages = Arrimg
        Img.animationDuration = 10
        Img.animationRepeatCount = 5
        Img.startAnimating()
        
        if sender.isEnabled
        {
            actvt.startAnimating()
        }
    }
   
    
    @IBAction func stop(_ sender: UIButton)
    {
        Img.stopAnimating()
        
        if sender.isEnabled
        {
            actvt.stopAnimating()
        }
    }
    
    
    @IBAction func Nxt(_ sender: UIButton)
    {
        let nxt1 : collc = self.storyboard?.instantiateViewController(withIdentifier: "collc") as! collc
        self.navigationController?.pushViewController(nxt1, animated: true)
        
    }
    
}
