//
//  segment17.swift
//  Navigate
//
//  Created by agile on 03/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit
import MapKit

class segment17: UIViewController, UICollectionViewDataSource ,UICollectionViewDelegate,CLLocationManagerDelegate
{

    @IBOutlet weak var segmnt: UISegmentedControl!
    
    @IBOutlet weak var segcoll: UICollectionView!
   
    var indo : Int = Int()
    @IBOutlet weak var segmap: MKMapView!
    
    var locmag = CLLocationManager()
    
    var topimg : [NSString] = ["img1","img2","img3","img4","img5","img6",]
    @IBOutlet weak var segimgview: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
//        let dict = ["a" : 1, "b" : 2, "c" : 1, "d" : 2]
//        
//        for (key , value) in dict
//        {
//            print(key[2]);
//        }
        
        var location = CLLocationCoordinate2DMake(23.0225,72.5714)
        var span = MKCoordinateSpanMake(2,2)
        var regin = MKCoordinateRegionMake(location, span)
        
        segmap.setRegion(regin, animated: true)
        
        let ano = MKPointAnnotation ()
        ano.coordinate = location
        ano.title = "Agile"
        ano.subtitle = "Ahmedabad"
        segmap.addAnnotation(ano)
        
        segcoll.isHidden = true
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return topimg.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let ccell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! SegmentCustomCell
        
        ccell.collimgview.image = UIImage(named: topimg[indexPath.row] as String)
        return ccell
    }
    
    @IBAction func segact(_ sender: UISegmentedControl)
    {
        if sender.selectedSegmentIndex == 0
        {
            segcoll.isHidden = true
            segmap.isHidden = false
        }
        else if sender.selectedSegmentIndex == 1
        {
            segmap.isHidden = true
            segcoll.isHidden = false
        }
        else if sender.selectedSegmentIndex == 2
        {
            segmap.isHidden = true
            segcoll.isHidden = true
            segimgview.isHidden = false
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        segmnt.selectedSegmentIndex = 2
        segmnt.sendActions(for: UIControlEvents.valueChanged)
        segimgview.image = UIImage(named: topimg[indexPath.row] as String)
        
        
    }
   
    

   
}
