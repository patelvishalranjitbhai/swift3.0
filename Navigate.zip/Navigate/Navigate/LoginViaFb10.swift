//
//  LoginViaFb10.swift
//  Navigate
//
//  Created by agile on 10/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class LoginViaFb10: UIViewController, UIWebViewDelegate
{

    @IBOutlet weak var fblogin: UIWebView!
    
    @IBOutlet weak var actvt: UIActivityIndicatorView!
    override func viewDidLoad()
   
    {
        super.viewDidLoad()
        
        fblogin.delegate = self
        
        actvt.hidesWhenStopped = true
        
        
        actvt.startAnimating()
        
    let req = NSURL(string: "http://www.facebook.com")
    let nsreq = NSURLRequest(url: req! as URL)
        fblogin.loadRequest(nsreq as URLRequest)

    }

    func webViewDidFinishLoad(_ webView: UIWebView)
    {
    
    actvt.stopAnimating()
        
        
    }
    
    

    @IBAction func Nxt(_ sender: UIButton)
    {
        let nxt : scrlvew11 = self.storyboard?.instantiateViewController(withIdentifier: "scrlvew11") as! scrlvew11
        self.navigationController?.pushViewController(nxt, animated: true)
        
    }
   

}
