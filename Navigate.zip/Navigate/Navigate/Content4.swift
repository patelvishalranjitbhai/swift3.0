//
//  Content.swift
//  Navigate
//
//  Created by BL@CK on 1/5/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class Content4: UIViewController, UITableViewDelegate ,UITableViewDataSource {
    
    
    var Arrnat = ["Sparx","Lancer","Relexo","Action"]
    var Arrint = ["Nike","Puma","Vans","Jordan","Acisc","Adidas","Lee","Crocs"]
    
    var nat : [UIImage] = [UIImage.init(named: "Sparx.png")!, UIImage.init(named: "Lancer.png")!, UIImage.init(named: "Relexo.png")!, UIImage.init(named: "Action.png")!]
    
    var Aint : [UIImage] = [UIImage.init(named: "Nike.png")!,UIImage.init(named: "Puma.png")!,UIImage.init(named: "Vans.png")!,UIImage.init(named: "Jordan.png")!,UIImage.init(named: "Acisc.png")!,UIImage.init(named: "Adidas.png")!, UIImage.init(named: "Lee.png")!,UIImage.init(named: "Crocs.png")!]


    @IBOutlet weak var tblview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Brands"
        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return Arrnat.count
        
        }
        else
        {
            return Arrint.count
        
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "a")
        
        if indexPath.section == 0
        {
            cell?.textLabel?.text = Arrnat[indexPath.row]
            cell?.imageView?.image = nat[indexPath.row]
        }
        else
        {
            cell?.textLabel?.text = Arrint[indexPath.row]
            cell?.imageView?.image = Aint[indexPath.row]
        }
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
       
        if section == 0
        {
            return "National"
        }else
        {
            return "International"
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let sgp : UITableViewCell = tableView.cellForRow(at: indexPath)!
        sgp.accessoryType = .checkmark
    }
    
    
    @IBAction func TapHm(_ sender: UIButton)
    {
        for seletedViewCOntroller in (self.navigationController?.viewControllers)!
        {
          if seletedViewCOntroller.isKind(of: Login1.self)
            {
        _ =  self.navigationController?.popToViewController(seletedViewCOntroller, animated: true)
            }
        }
    }
    
    @IBAction func gallaryTap(_ sender: UIButton)
    {
        
        let gallary : imagegallery = self.storyboard?.instantiateViewController(withIdentifier: "imagegallery") as! imagegallery
        
        self.navigationController?.pushViewController(gallary, animated: true)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
