//
//  slidemenu16.swift
//  Navigate
//
//  Created by agile on 20/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class slidemenu16: UIViewController, UITableViewDelegate, UITableViewDataSource {

   
    @IBOutlet weak var slide: UIView!
    
    @IBOutlet weak var btnout: UIButton!
    @IBOutlet weak var tblview: UITableView!
    
    var Arrnat = ["Sparx","Lancer","Relexo","Action"]
    var Arrint = ["Nike","Puma","Vans","Jordan","Acisc","Adidas","Lee","Crocs"]
    
    var nat : [UIImage] = [UIImage.init(named: "Sparx.png")!, UIImage.init(named: "Lancer.png")!, UIImage.init(named: "Relexo.png")!, UIImage.init(named: "Action.png")!]
    
    var Aint : [UIImage] = [UIImage.init(named: "Nike.png")!,UIImage.init(named: "Puma.png")!,UIImage.init(named: "Vans.png")!,UIImage.init(named: "Jordan.png")!,UIImage.init(named: "Acisc.png")!,UIImage.init(named: "Adidas.png")!, UIImage.init(named: "Lee.png")!,UIImage.init(named: "Crocs.png")!]
    
    var bool : Bool = Bool()
    var viewpoint : CGPoint = CGPoint()
    override func
        viewDidLoad()
    {
        super.viewDidLoad()
        bool = true
        slide.isHidden = true

        
   
        viewpoint = CGPoint(x: (self.slide.frame.maxX/2) - 180, y: self.slide.frame.maxY/2)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return Arrnat.count
            
        }
        else
        {
            return Arrint.count
            
        }

    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        if indexPath.section == 0
        {
            cell?.textLabel?.text = Arrnat[indexPath.row]
            cell?.imageView?.image = nat[indexPath.row]
        }
            
        else
        {
            cell?.textLabel?.text = Arrint[indexPath.row]
            cell?.imageView?.image = Aint[indexPath.row]
        }
        
        return cell!

    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0
        {
            return "National"
        }
            
        else
        {
            return "International"
        }
    }

    
    @IBAction func btnTAp(_ sender: UIButton)
    {
        slide.isHidden = false
        
        if bool == true
        {
            
            UIView.animate(withDuration: 1) {
                self.slide.center = CGPoint(x: (self.view.frame.width/2) - 50, y: self.view.frame.height/2)
                
                self.btnout.center = CGPoint(x: (self.slide.frame.maxX) + 50, y: 50)
            }
            bool = false
        }
        else
        {
            UIView.animate(withDuration: 1) {
                self.slide.center = self.viewpoint
                
                self.btnout.center = CGPoint(x: (self.slide.frame.maxX) + 50, y: 50)
            }
            bool = true
        }
        

    }
    
}
