//
//  ViewController15.swift
//  Navigate
//
//  Created by agile on 20/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class ViewController15: UIViewController {

    @IBOutlet weak var imgview: UIImageView!
    
     var simg : [String] = []
    var vos : Int = Int()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        imgview.image = UIImage(named: simg[vos] as String)
    }

    
}
