//
//  ViewController.swift
//  tabless
//
//  Created by agilemac-151 on 5/2/17.
//  Copyright © 2017 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {


    var sectionArr : [String] = []
    var itemsArr : [[String]] = []
    var data : [[String]] = []
    
    @IBOutlet weak var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        sectionArr = ["First","Second","Third"]
        itemsArr = [["A","B","C"],["D","E","F","G"],["H","I","J","k","L"]]
        data = [["mayank","vikram","dsadasd"],["hgfhv","hkjkj"]]
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {

        return sectionArr[section]
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {

        return sectionArr.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        let asnew = self.itemsArr[section]
        print(asnew)
        return asnew.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "cell")
        
      //  cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        
        let arr : [String] =  itemsArr[indexPath.section]
        cell?.textLabel?.text = arr[indexPath.row]
       // cell?.detailTextLabel?.text = (arr[indexPath.row])
        return cell!
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondVC = storyboard.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
       
       
        
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

