//
//  SwipeViewController.swift
//  NavigationDemo
//
//  Created by agile on 07/09/16.
//  Copyright © 2016 agile. All rights reserved.
//

import UIKit

class SwipeViewController: UIViewController {
    
    
    @IBOutlet var viewOrange: UIView!
    
    @IBOutlet var btnTest: UIButton!
    
    
    @IBOutlet var viewBlack: UIView!

    @IBOutlet var viewGreen: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        /*
        UISwipeGestureRecognizer *swipeRightOrange = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(slideToRightWithGestureRecognizer:)];
        swipeRightOrange.direction = UISwipeGestureRecognizerDirectionRight;
        
        UISwipeGestureRecognizer *swipeLeftOrange = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(slideToLeftWithGestureRecognizer:)];
        swipeLeftOrange.direction = UISwipeGestureRecognizerDirectionLeft;
        
        [self.viewOrange addGestureRecognizer:swipeRightOrange];
        [self.viewOrange addGestureRecognizer:swipeLeftOrange];
        
        
        UISwipeGestureRecognizer *swipeRightBlack = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(slideToRightWithGestureRecognizer:)];
        swipeRightBlack.direction = UISwipeGestureRecognizerDirectionRight;
        [self.viewBlack addGestureRecognizer:swipeRightBlack];
        
        
        UISwipeGestureRecognizer *swipeLeftGreen = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(slideToLeftWithGestureRecognizer:)];
        swipeLeftGreen.direction = UISwipeGestureRecognizerDirectionLeft;
        [self.viewGreen addGestureRecognizer:swipeLeftGreen];
 */
        
        let swipeRightOrange:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(slideToRightWithGestureRecognizer))
        swipeRightOrange.direction = UISwipeGestureRecognizerDirection.right;
        
        let swipeLeftOrange:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(slideToLeftWithGestureRecognizer))
        swipeLeftOrange.direction = UISwipeGestureRecognizerDirection.left;
        
        self.viewOrange.addGestureRecognizer(swipeRightOrange)
        self.viewOrange.addGestureRecognizer(swipeLeftOrange)
        
        let swipeRightBlack:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(slideToRightWithGestureRecognizer))
        swipeRightBlack.direction = UISwipeGestureRecognizerDirection.right;
        //[self.viewBlack addGestureRecognizer:swipeRightBlack];
        self.viewBlack.addGestureRecognizer(swipeRightBlack)
        
        let swipeLeftGreen:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(slideToLeftWithGestureRecognizer))
        swipeLeftGreen.direction = UISwipeGestureRecognizerDirection.left;
        //[self.viewGreen addGestureRecognizer:swipeLeftGreen];
        
        self.viewGreen.addGestureRecognizer(swipeLeftGreen)
        
       
        
        /*
        let singleTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleSingleTapGesture))
        
        btnTest.addGestureRecognizer(singleTapGestureRecognizer)
        */
        
        
    }
    
    func handleSingleTapGesture(tapGestureRecognizer:UITapGestureRecognizer)
    {
        print("single Tap")
    }
    

    
    
    @IBAction func testClick(sender: AnyObject)
    {
        print("test click")
    }
    
    
    func slideToLeftWithGestureRecognizer(gestureRecognizer:UISwipeGestureRecognizer)
    {
       
        UIView.animate(withDuration: 0.5, delay: 0, options: [], animations: {
            
            self.viewOrange.frame = self.viewOrange.frame.offsetBy(dx: -375.0, dy: 0.0);
            
            self.viewBlack.frame = self.viewBlack.frame.offsetBy(dx: -375.0, dy: 0.0);
            
            self.viewGreen.frame = self.viewGreen.frame.offsetBy(dx: -375.0, dy: 0.0);
            
        }, completion: { (finished: Bool) in
           
        })

        
        
    }
    func slideToRightWithGestureRecognizer(gestureRecognizer:UISwipeGestureRecognizer)
    {
        
        
        UIView.animate(withDuration: 0.5, delay: 0, options: [], animations: {
            //self.username.center.x += self.view.bounds.width
            
            self.viewOrange.frame = self.viewOrange.frame.offsetBy(dx: 375.0, dy: 0.0);
            
            self.viewBlack.frame = self.viewBlack.frame.offsetBy(dx: 375.0, dy: 0.0);
            
            self.viewGreen.frame = self.viewGreen.frame.offsetBy(dx: 375.0, dy: 0.0);
            
            
        }, completion: { (finished: Bool) in
          
        })
       // UIView.animateWithDuration(0.5, delay: 0, options: UIViewAnimationOptions.TransitionNone, animations: { () -> Void in
        
        

          //  }, completion: { (finished: Bool) -> Void in
                
                // you can do this in a shorter, more concise way by setting the value to its opposite, NOT value
        //})
    }
    
   

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
