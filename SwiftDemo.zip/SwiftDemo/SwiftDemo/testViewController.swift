//
//  testViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 27/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class testViewController: UIViewController,UITextFieldDelegate,UITextViewDelegate   {

    
    @IBOutlet var txtMobileNo: UITextField!
    
    
    @IBOutlet var txtLastName: UITextField!
    @IBOutlet var txtFirstName: UITextField!
    @IBOutlet var scrolView: UIScrollView!
    @IBOutlet var btnTest: UIButton!
    var getName:String?
    
    
    @IBOutlet var lblInfo: UILabel!
    
    @IBOutlet var txtUserName: UITextField!
    
    var arrStudent:NSMutableArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        //scrolView.contentSize = CGSize(width: 375, height: 1000)
        
        print(getName)
        
        
        var arrObj:[String] = ["1","2","3","4"]
        
        print(arrObj)
        
        arrObj.append("5")
        
        print(arrObj)
        
        
        let value = arrObj[2]
        
        print(value)
        
        let tmpObj:NSMutableArray = NSMutableArray()
        
        tmpObj.add("1")
        tmpObj.add("2")
        tmpObj.add("3")
        
        print(tmpObj)
        
        let test = tmpObj.object(at: 2)
        
        var dic:NSMutableDictionary = NSMutableDictionary()
        
        dic.setValue("testFirst", forKey: "firstName")
        dic.setValue("testLast", forKey: "lasttName")
        dic.setValue("testMiddle", forKey: "middleName")
        
        print(dic)
        
        let firstName = dic.object(forKey: "firstName")
        
        var someDict = [String : String]()
        
        // add a key and value
        
        someDict["1"] = "Ahmedabad"
        someDict["2"] = "Mehsana"
        someDict["3"] = "Baroda"
        someDict["4"] = "Surat"
        
        print(someDict)
        
        
        let userDefault:UserDefaults = UserDefaults.standard
        
        userDefault.setValue("test123456", forKey: "userName")
        
        
      //  let getText = lblInfo.text
        
      //  print(getText)
        
        
        
       // lblInfo.text = "Agile Infoways..."
        
        let lbl = UILabel(frame: CGRect(x: 20, y: 50, width: 320, height: CGFloat.greatestFiniteMagnitude))
        lbl.text = "Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label Dummy label"
        lbl.textColor = UIColor.red
        lbl.backgroundColor = UIColor.yellow
        
        lbl.numberOfLines = 0
        lbl.sizeToFit()
        
       // self.view.addSubview(lbl)
        
        
        
        
        
        
    
    }
    
    //MARK: - Uitextfield Delegate methods
    
    
    
    @IBAction func SubmitClick(_ sender: UIButton) {
        
        
        if(arrStudent.count == 5)
        {
            
            return
        }
        
        let firstName = txtFirstName.text
        let lastName = txtLastName.text
        let mobNo = txtMobileNo.text
        
        
        let dic :NSMutableDictionary = NSMutableDictionary()
        dic.setValue(firstName, forKey: "firstName")
        dic.setValue(lastName, forKey: "lastName")
        dic.setValue(mobNo, forKey: "mobNo")
        
        
        arrStudent.add(dic)
        
        txtMobileNo.text = ""
        txtFirstName.text = ""
        txtLastName.text = ""
        
        
        let getDic :NSMutableDictionary = arrStudent.object(at: 0) as! NSMutableDictionary
        let firstName1 = getDic.object(forKey: "firstName") as! String
        
        print(firstName1)
        
        
        
        
        
        
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        
        print("textFieldShouldBeginEditing")
        if(textField == txtFirstName)
        {
       /// scrolView.contentOffset = CGPoint(x: 0, y: 150)
        }
        else
        {
//scrolView.contentOffset = CGPoint(x: 0, y: 200)
    
        }
        
        return true
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        print("textFieldDidEndEditing")
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        print("textFieldShouldReturn")
        textField.resignFirstResponder()
        
        
        return true
        
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        print("shouldChangeCharactersIn")
        
    return true
    }
    
    @IBAction func signInCLick(_ sender: UIButton)
    {
        sender.backgroundColor = UIColor.red
        print(sender.tag)
        print("Sign in Clicked")
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        let userdefault = UserDefaults.standard
        
        let userName = userdefault.object(forKey: "userName")
        
        print(userName)
        
        
       // btnTest.backgroundColor = UIColor.orange
        
        
       // txtUserName.becomeFirstResponder()
        
        
    }
    
    @IBAction func testClick(_ sender: UIButton) {
        
        
        /*
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        let homeVC = storyBoard.instantiateViewController(withIdentifier: "homeViewController") as! homeViewController
        homeVC.testName = "test param"
        self.navigationController?.pushViewController(homeVC, animated: true)
        */
        
        print(txtUserName.text)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
