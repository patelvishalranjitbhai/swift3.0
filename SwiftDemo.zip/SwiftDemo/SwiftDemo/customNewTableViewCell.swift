//
//  customNewTableViewCell.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 17/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class customNewTableViewCell: UITableViewCell {

    @IBOutlet var lblItem: UILabel!
    
    @IBOutlet var txtValue: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
