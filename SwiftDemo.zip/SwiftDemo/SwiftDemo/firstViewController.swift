//
//  firstViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 07/04/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class firstViewController: UIViewController,testProtocol {

    @IBOutlet var lblCounter: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        let nc = NotificationCenter.default
        
        nc.addObserver(self, selector: #selector(userLoggedIn), name: Notification.Name("UserLoggedIn"), object: nil)
        
    }
    
    func userLoggedIn()
    {
        print("userLoggedIn called")
    }
    
    func testMethod() {
        
        print("testMethod called")
        
        var getValue = Int(lblCounter.text!)
        
        getValue = getValue! + 1
        
        lblCounter.text = NSString(format: "%d", getValue!) as String
        
        
        
        
        
    }
    
    
    @IBAction func buttonClick(_ sender: Any) {
        
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondVC = storyBoard.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
       // secondVC.delegate = self
        self.navigationController?.pushViewController(secondVC, animated: true)
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
