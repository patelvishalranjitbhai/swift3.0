//
//  valuechangeViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 24/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class valuechangeViewController: UIViewController {

    @IBOutlet var progressView: UIProgressView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        progressView.progress = 0.9
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func selectSegment(_ sender: UISegmentedControl) {
        
        print(sender.selectedSegmentIndex)
        
    }
    
    
    @IBAction func switchClick(_ sender: UISwitch){
        
        print(sender.isOn)
        
        if(sender.isOn)
        {
            sender.setOn(false, animated: true)
        }
        else
        {
            sender.setOn(true, animated: true)
        }
        
        
    }
    
    @IBAction func stepperClick(_ sender: UIStepper) {
        
        print(sender.value)
        
    }
    
    
    @IBAction func sliderClick(_ sender: UISlider) {
        
        print(sender.value)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
