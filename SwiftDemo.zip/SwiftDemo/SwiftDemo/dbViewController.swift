//
//  dbViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 21/04/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class dbViewController: UIViewController {

    
    @IBOutlet var txtFirstName: UITextField!
    
    @IBOutlet var txtLastName: UITextField!
    
    
    @IBOutlet var txtEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
       // apiCall()
        
        GETMethod()
    }
    
    func GETMethod()
    {
        /*
        let urlPath: String = "http://202.131.123.211/UdgamApi_v4/App_Services/UdgamService.asmx/GetAllTeacherData?StudentId=2011111"
        let url: NSURL = NSURL(string: urlPath)!
        
        let request1: NSMutableURLRequest = NSMutableURLRequest(url: url as URL)
        
        request1.httpMethod = "GET"
        
        let queue:OperationQueue = OperationQueue()
        
        NSURLConnection.sendA
        
        
        NSURLConnection.sendAsynchronousRequest(request1 as URLRequest, queue: queue, completionHandler:{ (response: URLResponse?, data: NSData?, error: NSError?) -> Void in
            
            do
            {
                if let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: []) as? NSDictionary
                {
                    print("ASynchronous\(jsonResult)")
                    
                    let teacherArray:NSMutableArray = jsonResult.objectForKey("teacherDetail") as! NSMutableArray
                    
                    
                    print(teacherArray)
                    
                    
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
            
            
        })
        
        print("check ASync Method")
 */
        
        var request = URLRequest(url: URL(string: "http://202.131.123.211/UdgamApi_v4/App_Services/UdgamService.asmx/GetAllTeacherData?StudentId=2011111")!)
        request.httpMethod = "GET"
        let session = URLSession.shared
        
        session.dataTask(with: request) {data, response, err in
            print("Entered the completionHandler")
            print(response)
            }.resume()
        
    }
    
    
    func apiCall()
    {
        /*
        let urlPath: String = "http://202.131.123.211/UdgamApi_v4/App_Services/UdgamService.asmx/GetAllTeacherData?StudentId=2011111"
        let url: NSURL = NSURL(string: urlPath)!
        
        let request1: NSMutableURLRequest = NSMutableURLRequest(url: url as URL)
        
        request1.HTTPMethod = "GET"
        
        let queue:NSOperationQueue = NSOperationQueue()
        
        NSURLConnection.sendAsynchronousRequest(request1, queue: queue, completionHandler:{ (response: NSURLResponse?, data: NSData?, error: NSError?) -> Void in
            
            do
            {
                if let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: []) as? NSDictionary
                {
                    print("ASynchronous\(jsonResult)")
                    
                    let teacherArray:NSMutableArray = jsonResult.objectForKey("teacherDetail") as! NSMutableArray
                    
                    
                    print(teacherArray)
                    
                    
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
            
            
        })
        
        print("check ASync Method")
 */
       // let param = ["StudentId": "2011111"]
        
       // let request = NSMutableURLRequest(url: URL(string: "Your API URL here" ,param: param))!,
       // cachePolicy: .useProtocolCachePolicy,
        //timeoutInterval:"Your request timeout time in Seconds")
        
        
        let urlPath: String = "http://202.131.123.211/UdgamApi_v4/App_Services/UdgamService.asmx/GetAllTeacherData?StudentId=2011111"
        
        let request = NSMutableURLRequest(url: URL(string:urlPath)!, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 0)
        
        
        request.httpMethod = "GET"
       // request.allHTTPHeaderFields = headers as? [String : String]
        
        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: request as URLRequest) {data,response,error in
            let httpResponse = response as? HTTPURLResponse
            
            if (error != nil) {
                print(error)
            } else {
                print(httpResponse)
            }
            
            DispatchQueue.main.async {
                //Update your UI here
            }
            
        }
        dataTask.resume()
    }
    

    @IBAction func InsertDB(_ sender: UIButton) {
    
    
        let firstName = txtFirstName.text
        let lastName = txtLastName.text
        let email = txtEmail.text
        
        let isInserted = ModelManager.getInstance().InsertData(firstName: firstName!, lastName: lastName!, email: email!)
        
        print("Inserted Value = \(isInserted)")
        
        
    
    }
    
    
    @IBAction func selectAllClick(_ sender: UIButton) {
        
        
        let arrStudent = ModelManager.getInstance().getAllData()
        print(arrStudent)
        
        
        
    }
    
    
    @IBAction func deleteClick(_ sender: UIButton) {
        let isDeleted = ModelManager.getInstance().DeleteRecord(rollNo: 3)
        
        let arrStudent = ModelManager.getInstance().getAllData()
        print(arrStudent)
        
    }
    @IBAction func updateRecord(_ sender: UIButton) {
        
        let isUpdated = ModelManager.getInstance().UpdateData(firstName: "fUpdate", lastName: "lUpdate", email: "agile@agile.com", sid: 2)
        
        print(isUpdated)
        
        let arrStudent = ModelManager.getInstance().getAllData()
        print(arrStudent)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
