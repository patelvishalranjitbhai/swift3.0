//
//  colViewDemoViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 20/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class colViewDemoViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet var colView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        
        let flowLayout :UICollectionViewFlowLayout = UICollectionViewFlowLayout();
        
        // flowLayout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        
        //flowLayout.itemSize = CGSize(width: (SCREEN_WIDTH-40)/3, height: (SCREEN_WIDTH-40)/3)
        
        //let getDiffn = (SCREEN_WIDTH - 265) / 2
        
        flowLayout.minimumInteritemSpacing = 10
        flowLayout.minimumLineSpacing = 5
        flowLayout.sectionInset = UIEdgeInsetsMake(20, 20, 20, 20)
        colView.setCollectionViewLayout(flowLayout, animated: true)
    }

    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        
        return CGSize(width: 75 , height: 60)
        //return CGSize(((SCREEN_WIDTH - 30) / 3), ((SCREEN_WIDTH - 30) / 3))
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 9
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = colView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        
        return cell
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
