//
//  ViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 08/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       testWithoutParameter()
        testWithParameter(a: 50, b: 50, msg: "addition")
        
        let test = testWithReturnValue(a: 50, b: 50, msg: "test Messgae")
        print(test)
        
        
        print(" first viewDidLoad")
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        print(" first viewWillAppear")
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("first viewDidAppear")
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print("first viewWillDisappear")
        
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("first viewDidDisappear")

    }

    
    func testWithParameter(a:Int,b:Int,msg:String)
    {
        print(a + b)
        print(msg)
    }
    func testWithReturnValue(a:Int,b:Int,msg:String) -> Int
    {
        return a + b
    }
    
    
    func testWithoutParameter()
    {
        let a  = 5
        let b = 10
        print(a + b)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "testView"
        {
            print("This is the Name Picker")
            if let destinationVC = segue.destination as? testViewController {
                //destinationVC.getName = "msg pass here"
                
                destinationVC.getName = "my user name"
            }
            
            
        }
 
        
    }
    
    @IBAction func SignClick(_ sender: Any) {
        
        
        let  storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let homeVC = storyboard.instantiateViewController(withIdentifier: "homeViewController") as? homeViewController
        
        self.navigationController?.pushViewController(homeVC!, animated: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

