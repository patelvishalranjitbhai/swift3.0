//
//  homeViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 15/02/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class homeViewController: UIViewController {

    
    var getName = ""
    var testName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("2 viewDidLoad")
        print(testName)
        
        print(getName)
        
        var a:Int = 5
        var b:Int?
        
        print(a)
        print(b)
        
        
        var c:Int? = nil
        
        print(c)
        
        
        var d:Int!
        
       // print(d)
        
        
        
        self.navigationController?.navigationBar.isHidden  = true
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        print("2 viewWillAppear")
        
    }
    
    
    @IBAction func BackClick(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("2 viewDidAppear")
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        print("2 viewWillDisappear")
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("2 viewDidDisappear")
    }
    
    
    @IBAction func BackAction(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        self.navigationController?.popToRootViewController(animated: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
