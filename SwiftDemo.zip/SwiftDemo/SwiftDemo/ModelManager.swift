//
//  ModelManager.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 21/04/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit


let sharedInstance = ModelManager()

class ModelManager: NSObject {
    
    var database:FMDatabase? = nil
    
    
    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            
            let fileURL = documentsURL.appendingPathComponent("UserDB.sqlite" as String)
            
            sharedInstance.database = FMDatabase(path: fileURL.path)
            
            
        }
        
        return sharedInstance
    }

    func InsertData(firstName:String,lastName:String,email:String) -> Bool
    {
        
        sharedInstance.database!.open()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO tbluser (firstName, lastName,email) VALUES (?, ?,?)", withArgumentsIn: [firstName,lastName,email ]);
        
        print(sharedInstance.database!.lastErrorMessage())
        
        sharedInstance.database!.close()
        
        return isInserted
    }
    func UpdateData(firstName:String,lastName:String,email:String,sid:Int) -> Bool
    {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE Tbluser SET firstName=?, lastname=?,email=? WHERE id=?", withArgumentsIn: [firstName, lastName, email,sid])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    func getAllData() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM tbluser", withArgumentsIn: nil)
        
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        
        if (resultSet != nil)
        {
            while resultSet.next()
            {
                let studentInfo : NSMutableDictionary = NSMutableDictionary()
                
                
                //let firstName = resultSet.string(forColumn: "firstName")
                
                let email = resultSet.string(forColumn: "email")
                
                
                studentInfo.setValue(resultSet.string(forColumn: "firstName"), forKey: "firstName")
                
                
                studentInfo.setValue(resultSet.string(forColumn: "lastName"), forKey: "lastName")
                
                studentInfo.setValue(email, forKey: "email")
                
                
                let studentId:Int = Int(resultSet.int(forColumn: "id"))
                
                studentInfo.setValue(studentId, forKey: "sid")
                
                
                print(studentInfo)
                
                marrStudentInfo.add(studentInfo)
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
        
    }
    
    func DeleteRecord(rollNo:Int) -> Bool
    {
        sharedInstance.database!.open()
        
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM Tbluser WHERE id=?", withArgumentsIn: [rollNo])
        
        sharedInstance.database!.close()
        
        return isDeleted
    }
    
    


    
    
}
