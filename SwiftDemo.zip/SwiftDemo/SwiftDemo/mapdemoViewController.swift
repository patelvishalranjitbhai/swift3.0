//
//  mapdemoViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 27/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit
import MapKit

class mapdemoViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {
    
    
    @IBOutlet var mapView: MKMapView!
    
      let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        // 1)
        mapView.mapType = MKMapType.standard
        
        // 2)
        let location = CLLocationCoordinate2D(latitude: 23.0225,longitude: 72.5714)
        
        // 3)
        let span = MKCoordinateSpanMake(0.75, 0.75)
        let region = MKCoordinateRegion(center: location, span: span)
        mapView.setRegion(region, animated: true)
       
        // 4)
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = "Agile Infoways"
        annotation.subtitle = "Ahmedabad"
        mapView.addAnnotation(annotation)
        
        self.locationManager.requestAlwaysAuthorization()
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled()
        {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }

        
        
        
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        
    locationManager.stopUpdatingLocation()
        
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        locationManager.stopUpdatingLocation()
        
        if ((error) != nil)
        {
            print(error)
        }
    }
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        // Don't want to show a custom image if the annotation is the user's location.
        guard !(annotation is MKUserLocation) else {
            return nil
        }
        
        // Better to make this class property
        let annotationIdentifier = "AnnotationIdentifier"
        
        var annotationView: MKAnnotationView?
        annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: annotationIdentifier)
        
        //annotationView?.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        
        let btn = UIButton(type:.detailDisclosure)
        
        btn.addTarget(self, action: #selector(mapdemoViewController.ratingButtonTapped(sender:)), for: .touchUpInside)
        annotationView?.rightCalloutAccessoryView = btn
        
        
        annotationView?.canShowCallout = true
        annotationView?.image = UIImage(named: "pinMapD")
        
        
        return annotationView
    }

    func ratingButtonTapped(sender:UIButton)
    {
        print("button click")
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
