//
//  customCollectionCell.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 20/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class customCollectionCell: UICollectionViewCell {
    
    @IBOutlet var lblItem: UILabel!
    
    
}
