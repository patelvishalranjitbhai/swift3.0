//
//  ImagePickerDemoViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 22/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class ImagePickerDemoViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate
 {

    @IBOutlet var imgPreview: UIImageView!
    
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        picker.delegate = self
    }

    @IBAction func SelectPic(_ sender: UIButton) {
        
        
        let alert = UIAlertController(title: "Photo", message: "Please Choose Source Type", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action) in
            //execute some code when this option is selected
            
        }))
        alert.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action) in
            //execute some code when this option is selected
            
            self.photoFromLibrary()
            
        }))
        
        self.present(alert, animated: true, completion: nil)
        
        
    }
    func photoFromLibrary()
    {
        picker.allowsEditing = true   // true
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }
    
    //MARK: - Delegates
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        print(info)
        
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        let editedImage = info[UIImagePickerControllerEditedImage] as! UIImage
        
        imgPreview.contentMode = .scaleAspectFit //3
        imgPreview.image = editedImage //4
        dismiss(animated:true, completion: nil) //5
        
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
