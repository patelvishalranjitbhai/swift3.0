//
//  tblViewdemoViewController.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 15/03/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class tblViewdemoViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
{

    
    @IBOutlet var tblItem: UITableView!
    
    
    var arrCountry:NSMutableArray = NSMutableArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       // tblItem.delegate = self
       // tblItem.dataSource = self
        
        
        tblItem.register(UINib(nibName: "customNewTableViewCell", bundle: nil), forCellReuseIdentifier: "customNewTableViewCell")
        
        
        var countryDic :NSMutableDictionary = NSMutableDictionary()
        var stateArray:NSMutableArray = NSMutableArray()
        stateArray.add("Gujarat")
        stateArray.add("Rajasthan")
        stateArray.add("Maharastra")
        
        countryDic.setValue(stateArray, forKey: "India")
        
        
        arrCountry.add(countryDic)
        
         countryDic  = NSMutableDictionary()
         stateArray = NSMutableArray()
        stateArray.add("state 1")
        stateArray.add("state 2")
        stateArray.add("state 3")
        
        countryDic.setValue(stateArray, forKey: "USA")
        
        arrCountry.add(countryDic)
        let getDic = arrCountry.object(at: 0) as! NSMutableDictionary
        print(getDic)
        
        let getStateArray = getDic.object(forKey: "India") as? NSMutableArray
        
        print(getStateArray)
        
        
        
        
        
        print(arrCountry)
        
        
        
    }
    
    
    
    //MARK: - UItableview delgate and datasource methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 20
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return 20
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(section == 0)
        {
            return 3
        }
        else if(section == 1)
        {
            return 5
        }
        return 10
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 68
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        print(indexPath.row)
        
        let cell:customNewTableViewCell = tableView.dequeueReusableCell(withIdentifier: "customNewTableViewCell", for: indexPath) as! customNewTableViewCell
       // cell.textLabel?.text = String(format: "%d", indexPath.row)
        
        cell.lblItem.text = String(format: "%d", indexPath.row)
        
       
        
        return cell
        
        
        
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print(indexPath.row)
        
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
