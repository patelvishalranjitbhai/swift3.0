//
//  TableViewCell.swift
//  sqli1
//
//  Created by Akshay on 29/05/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var lblphoneno: UILabel!
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var lbluserid: UILabel!
    
    @IBOutlet weak var lblpassword: UILabel!
    @IBOutlet weak var lblemailid: UILabel!
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
