//
//  ViewController.swift
//  sqli1
//
//  Created by Akshay on 27/05/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var txtpassword: UITextField!
    @IBOutlet weak var txtemailid: UITextField!
    @IBOutlet weak var txtphoneno: UITextField!
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtuserid: UITextField!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let nc = NotificationCenter.default
    
        nc.addObserver(self, selector: #selector(userLoggedIn) , name: NSNotification.Name(rawValue: userid), object: nil)
         nc.addObserver(self, selector: #selector(userLoggedIn) , name: NSNotification.Name(rawValue: password), object: nil)
         nc.addObserver(self, selector: #selector(userLoggedIn) , name: NSNotification.Name(rawValue: name), object: nil)
         nc.addObserver(self, selector: #selector(userLoggedIn) , name: NSNotification.Name(rawValue: email), object: nil)
         nc.addObserver(self, selector: #selector(userLoggedIn) , name: NSNotification.Name(rawValue: phoneno), object: nil)
        
    }
    
    func userLoggedIn () {
        
          }
   
    
    @IBAction func btnupdate(_ sender: UIButton) {
        
        let updated = ModelManager.getInstance().UpdateData(NAME: txtname.text!, PHONE_NO: txtphoneno.text!, EMAIL_ID: txtemailid.text!, PASSWORD: txtpassword.text!,USER_ID: txtuserid.text!)
        
        print("Updated Value = \(updated)")
        
        let arrEmp = ModelManager.getInstance().getAllData()
        
        print(arrEmp)
      clearData()
    }
    
    
    @IBAction func btnDelete(_ sender: UIButton) {
        
        let delete = ModelManager.getInstance().DeleteRecord(USER_ID: txtuserid.text!)
        
          print("Delete Value = \(delete)")
        
        clearData()
        
    }
    
    
    @IBAction func Next(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondVC = storyboard.instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
        
        self.navigationController?.pushViewController(secondVC, animated: true)
   
    }
    
    
   
    @IBAction func btnSave(_ sender: UIButton) {
        
        let userid = txtuserid.text
        let name = txtname.text
        let phoneno = txtphoneno.text
        let emailid = txtemailid.text
        let password = txtpassword.text
        
        let isInserted = ModelManager.getInstance().InsertData(USER_ID: userid!, NAME: name!, PHONE_NO: phoneno!, EMAIL_ID: emailid!, PASSWORD: password!)
        
        
        print("Inserted Value = \(isInserted)")
        

        
        
       clearData()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        
      
                txtuserid.text = userid
                txtpassword.text = password
                txtname.text = name
                txtemailid.text = email
                txtphoneno.text = phoneno
        
    }
    

    
    func clearData()
    {
    
    txtuserid.text = ""
        txtphoneno.text = ""
        txtemailid.text = ""
        txtpassword.text = ""
        txtname.text = ""
    }
    

}

