//
//  loginViewController.swift
//  sqli1
//
//  Created by Akshay on 28/05/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class loginViewController: UIViewController {

    @IBOutlet weak var txtusertid: UITextField!
    @IBOutlet weak var txtpassword: UITextField!
 
    @IBAction func tableview(_ sender: UIButton) {
        
         var arrEmp1 = ModelManager.getInstance().getAllData()
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
     
        
        for var i in 0..<arrEmp1.count
        {
            
            let dic = arrEmp1[i] as! NSDictionary
            var userid = dic.value(forKey: "USER_ID") as! String
            var password = dic.value(forKey: "PASSWORD") as! String
            
            if(txtusertid.text == userid && txtpassword.text == password)
                
            {

        
        let tableVC = storyboard.instantiateViewController(withIdentifier: "tableViewController") as! tableViewController
        
          tableVC.alldata = arrEmp1 as NSArray
        
        
        self.navigationController?.pushViewController(tableVC, animated: true)
        
            }
        }
 
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
  
    @IBAction func Login(_ sender: UIButton) {
        
        
       let arrEmp = ModelManager.getInstance().getAllData()
    
        print(arrEmp)
       
        
     
   
    print(arrEmp)
     
        
       
   
       for var i in 0..<arrEmp.count
        {
         
            let dic = arrEmp[i] as! NSDictionary
            var userid = dic.value(forKey: "USER_ID") as! String
            var password = dic.value(forKey: "PASSWORD") as! String
        
        
            if(txtusertid.text == userid && txtpassword.text == password)
            
            {
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let thirdVC = storyboard.instantiateViewController(withIdentifier: "thirdViewController") as! thirdViewController
                    
                    
                   thirdVC.data = arrEmp[i] as! NSMutableDictionary
                    
                    
                    self.navigationController?.pushViewController(thirdVC, animated: true)

           }
   }
    
        
   
     
//        
//   
//       for var i in 0..<arrEmp.count
//        {
//            if txtusertid.text == (arrEmp[i] as! NSDictionary).value(forKey: "USER_ID") as? String && txtpassword.text == (arrEmp[i] as! NSDictionary).value(forKey: "PASSWORD") as? String
        
        
        
 //           {
 //               let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
  //              let thirdVC = storyboard.instantiateViewController(withIdentifier: "thirdViewController") as! thirdViewController
                
//
//                thirdVC.data = arrEmp[i] as! NSMutableDictionary
//                
                
  //              self.navigationController?.pushViewController(thirdVC, animated: true)
                
//            }
//        }
//     
 
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


}
