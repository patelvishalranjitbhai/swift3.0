//
//  bridge-header.h
//  sqli1
//
//  Created by Akshay on 27/05/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

#ifndef bridge_header_h
#define bridge_header_h

#import "FMDatabase.h"
#import "FMDatabaseAdditions.h"
#import "FMResultSet.h"


#endif /* bridge_header_h */
