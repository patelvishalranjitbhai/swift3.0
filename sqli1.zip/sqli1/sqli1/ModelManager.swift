//
//  ModelManager.swift
//  SwiftDemoApp
//
//  Created by agile on 18/06/16.
//  Copyright © 2016 agile. All rights reserved.
//

import UIKit

let sharedInstance = ModelManager()

class ModelManager: NSObject
{
    
    var database:FMDatabase? = nil
    
    
    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            
            let fileURL = documentsURL.appendingPathComponent("registraion.sqlite" as String)
            
            sharedInstance.database = FMDatabase(path: fileURL.path)
            
            
        }
        
        return sharedInstance
    }
    
    func InsertData(USER_ID:String,NAME:String,PHONE_NO:String,EMAIL_ID:String,PASSWORD:String) -> Bool
    {
        
       
        print(USER_ID)
        print(NAME)
        print(PHONE_NO)
        print(EMAIL_ID)
        print(PASSWORD)
        
        
        sharedInstance.database!.open()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO student (USER_ID, NAME,PHONE_NO,EMAIL_ID,PASSWORD) VALUES (?, ?, ?, ?, ?)", withArgumentsIn: [USER_ID,NAME,PHONE_NO,EMAIL_ID,PASSWORD]);
        
        print(sharedInstance.database!.lastErrorMessage())
        
        sharedInstance.database!.close()
        
        return isInserted
}
    
    
    func getAllData() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM student", withArgumentsIn: nil)
       
        
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        
        if (resultSet != nil)
        {
            while resultSet.next()
            {
                let studentInfo : NSMutableDictionary = NSMutableDictionary()
       
                
                studentInfo.setValue(resultSet.string(forColumn: "USER_ID"), forKey: "USER_ID")
                studentInfo.setValue(resultSet.string(forColumn: "NAME"), forKey: "NAME")
                studentInfo.setValue(resultSet.string(forColumn: "PHONE_NO"), forKey: "PHONE_NO")
                studentInfo.setValue(resultSet.string(forColumn: "EMAIL_ID"), forKey: "EMAIL_ID")
                studentInfo.setValue(resultSet.string(forColumn: "PASSWORD"), forKey: "PASSWORD")
              
                
              
                /*
                studentInfo.setValue(resultSet.string(forColumn: "firstName"), forKey: "firstName")
                
                
                studentInfo.setValue(resultSet.string(forColumn: "marks"), forKey: "Marks")
                
                let studentId:Int = Int(resultSet.int(forColumn: "id"))
                
                studentInfo.setValue(studentId, forKey: "RollNo")
           */
                
                
                /*
                 studentInfo.RollNo = resultSet.stringForColumn("RollNo")
                 studentInfo.Name = resultSet.stringForColumn("Name")
                 studentInfo.Marks = resultSet.stringForColumn("Marks")
                 */
                marrStudentInfo.add(studentInfo)
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
        
    }
    
    func UpdateData(NAME:String,PHONE_NO:String,EMAIL_ID:String,PASSWORD:String,USER_ID:String) -> Bool
    {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE student SET NAME=?, PHONE_NO=?, EMAIL_ID=?, PASSWORD=? WHERE USER_ID=?", withArgumentsIn: [NAME,PHONE_NO,EMAIL_ID,PASSWORD,USER_ID])
        sharedInstance.database!.close()
        return isUpdated
    }

    
    
    func DeleteRecord(USER_ID:String) -> Bool
    {
        sharedInstance.database!.open()
        
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM student WHERE USER_ID=?", withArgumentsIn: [USER_ID])
        
        sharedInstance.database!.close()
        
        return isDeleted
    }


    
}
