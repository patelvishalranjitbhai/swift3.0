//
//  thirdViewController.swift
//  sqli1
//
//  Created by Akshay on 29/05/17.
//  Copyright © 2017 Akshay. All rights reserved.
//


import UIKit

var name = String()
var userid = String()
var password = String()
var email = String()
var phoneno = String()


class thirdViewController: UIViewController {

    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var lbluserid: UILabel!
    
    @IBOutlet weak var lblpassword: UILabel!
    @IBOutlet weak var lblemail: UILabel!
    @IBOutlet weak var lblphoneno: UILabel!
    
    
    var data = NSMutableDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        print(data)
        
        lbluserid.text = data.object(forKey: "USER_ID") as? String
        lblname.text = data.object(forKey: "NAME") as? String
        lblphoneno.text = data.object(forKey: "PHONE_NO") as? String
        lblemail.text = data.object(forKey: "EMAIL_ID") as? String
        lblpassword.text = data.object(forKey: "PASSWORD") as? String
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func declaration(){
        
        name = lblname.text!
        userid = lbluserid.text!
        password = lblpassword.text!
        email = lblemail.text!
        phoneno = lblphoneno.text!
    
    }
    

    @IBAction func btnedit(_ sender: UIButton) {
        
       declaration()
        
        let nc = NotificationCenter.default
        
        nc.post(name: NSNotification.Name(rawValue: name), object: nil)
        nc.post(name: NSNotification.Name(rawValue: userid), object: nil)
        nc.post(name: NSNotification.Name(rawValue: password), object: nil)
        nc.post(name: NSNotification.Name(rawValue: email), object: nil)
        nc.post(name: NSNotification.Name(rawValue: phoneno), object: nil)
navigationController?.popToRootViewController(animated: true)
        
        
        
    }
    
    
    
    
    /*
     
     
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
