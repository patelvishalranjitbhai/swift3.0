//
//  customCollectionViewCell.swift
//  imagepicker
//
//  Created by Akshay on 3/23/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class customCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var cellimage: UIImageView!
    
    @IBOutlet weak var lblname: UILabel!
}
