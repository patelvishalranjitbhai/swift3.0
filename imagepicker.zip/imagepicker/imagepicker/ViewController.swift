//
//  ViewController.swift
//  imagepicker
//
//  Created by Akshay on 3/23/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource {
   
    @IBOutlet weak var image: UIImageView!
	
    @IBOutlet weak var collection: UICollectionView!
    let picker = UIImagePickerController()

    
    var imagesArray = NSMutableArray()
    
    
    @IBAction func tblupload(_ sender: UIButton) {
    
        
        
    let alert = UIAlertController(title: "Photo", message: "Choose Photo", preferredStyle: .actionSheet)
      
        
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action) in
        
        
        }))
        
        alert.addAction(UIAlertAction(title: "Gallary", style: .default, handler: { (action) in
            
            self.gallary()
    
        }))
        
        present(alert,animated: true,completion: nil)
        
        
        
    }
    
    func gallary() {
        
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker,animated: true ,completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let editedView = info[UIImagePickerControllerEditedImage] as! UIImage
        image.contentMode = .scaleAspectFit
        image.image = editedView
        imagesArray.add(editedView)
        dismiss(animated: true, completion: nil)
     
     

        collection.reloadData()
        
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return imagesArray.count 
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:customCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! customCollectionViewCell
    
        cell.cellimage.image = imagesArray[indexPath.row] as? UIImage
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        imagesArray[indexPath.item] = ""
        collection.reloadData()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        picker.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    
    }
}
