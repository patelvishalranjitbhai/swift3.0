//
//  ModelManager.swift
//  SwiftDemo
//
//  Created by agilemac-74 on 21/04/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit


let sharedInstance = ModelManager()

class ModelManager: NSObject {
    
    var database:FMDatabase? = nil
    
    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            
            let fileURL = documentsURL.appendingPathComponent("CompanyDB.sqlite" as String)
            
            sharedInstance.database = FMDatabase(path: fileURL.path)
            
            
        }
        
        return sharedInstance
    }

    func InsertData(empName:String,city:String) -> Bool
    {
        
        sharedInstance.database!.open()
        
        
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO tblEmp (name, city) VALUES (?, ?)", withArgumentsIn: [empName,city]);
        
        print(sharedInstance.database!.lastErrorMessage())
        
        sharedInstance.database!.close()
        
        return isInserted
    }
    func UpdateData(firstName:String,lastName:String,email:String,sid:Int) -> Bool
    {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE Tbluser SET firstName=?, lastname=?,email=? WHERE id=?", withArgumentsIn: [firstName, lastName, email,sid])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    func getAllData() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM tblEmp", withArgumentsIn: nil)
        
        let marrEmpInfo : NSMutableArray = NSMutableArray()
        
        if (resultSet != nil)
        {
            while resultSet.next()
            {
                let studentInfo : NSMutableDictionary = NSMutableDictionary()
                
                
                //let firstName = resultSet.string(forColumn: "firstName")
                
                
                let empName = resultSet.string(forColumn: "name")
                studentInfo.setValue(empName, forKey: "name")
                
                
                
                let city = resultSet.string(forColumn: "city")
                studentInfo.setValue(city, forKey: "city")

                
                
                let empId:Int = Int(resultSet.int(forColumn: "id"))
                studentInfo.setValue(empId, forKey: "eid")
                
                
                print(studentInfo)
                
                marrEmpInfo.add(studentInfo)
            }
        }
        
        
        
        sharedInstance.database!.close()
        
        
        return marrEmpInfo
        
    }
    
    func DeleteRecord(rollNo:Int) -> Bool
    {
        sharedInstance.database!.open()
        
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM Tbluser WHERE id=?", withArgumentsIn: [rollNo])
        
        sharedInstance.database!.close()
        
        return isDeleted
    }
    
    


    
    
}
