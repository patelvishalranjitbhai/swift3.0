//
//  ViewController.swift
//  jsondata
//
//  Created by Akshay on 01/06/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   var dic = NSDictionary()
    
    @IBAction func btnnext(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondVC = storyboard.instantiateViewController(withIdentifier: "tableViewController") as! tableViewController
        
        secondVC.dictt = dic
        
        self.navigationController?.pushViewController(secondVC, animated: true)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
   
    makeGetAPICall()
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func makeGetAPICall()
    {
        let urlPath: String = "https://api.foursquare.com/v2/venues/search?client_id=XYNBAG003OVPI4J0VVENVWGH1NWJN4GK45K4K4JISPON3E1J&client_secret=NZDFTJCIVRZQHI0EIPOSFO5IXB04RXFQZVASZCKSMNDGNDTX&v=20130815%20&ll=40.7463956,-73.9852992"
        
        
        let url = URL(string: urlPath)
        
        var urlRequest = URLRequest(url: url!)
        
        // let postString = "StudentId=2011111" //"id=13&name=Jack"
        
        urlRequest.httpMethod = "GET"
        
        // urlRequest.httpBody = postString.data(using: String.Encoding.utf8)
        
        
        // set up the session
        let config = URLSessionConfiguration.default
        
        let session = URLSession(configuration: config)
        
        
        
        
        let task = session.dataTask(with: urlRequest) { (data, response, error) in
            
            do {
                
                guard let getResponseDic = try JSONSerialization.jsonObject(with: data!, options: []) as? [String: AnyObject]
                    else
                {
                    print("error trying to convert data to JSON")
                    return
                }
                // now we have the todo, let's just print it to prove we can access it
                
                print(getResponseDic as NSDictionary)
                
                
                 self.dic = getResponseDic as NSDictionary
                
                //  let dic = getResponseDic as NSDictionary
                
//                let response = dic.object(forKey: "response") as!NSDictionary
//                let venus = response.object(forKey: "venues") as! NSArray
//               
//                let index0 = venus.object(at: 0) as! NSDictionary
//                
//                let location = index0.object(forKey: "location") as! NSDictionary
//                
//                
//                let lat = location.object(forKey: "lat")
//                let lng = location.object(forKey: "lng")
//                
//                print(lat)
//                print(lng)
              /*
                let msg = dic.object(forKey: "message")
                
                print(msg)
                let arrObj = dic.object(forKey: "teacherDetail") as! NSArray
                print(arrObj)
                
                let teacherDIc = arrObj.object(at: 0) as? NSDictionary
                
                let empName = teacherDIc?.object(forKey: "TeacherName")
                
                print(empName)
                */
                
                // the todo object is a dictionary
                // so we just access the title using the "title" key
                // so check for a title and print it if we have one
                
                // print("The title is: " + todoTitle)
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
            
            
            
            
        }
        
        task.resume()
        
        
    }


}

