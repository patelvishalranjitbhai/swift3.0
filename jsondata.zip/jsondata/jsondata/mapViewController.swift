//
//  mapViewController.swift
//  jsondata
//
//  Created by Akshay on 03/06/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit
import MapKit

class mapViewController: UIViewController {

    var long = Double()
    var lati = Double()
    var nam = String()
    var str = String()
    var add = String()
    @IBOutlet weak var map: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        mapview()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
    
    

    func mapview()
    {
    
        
        // 1)
        map.mapType = MKMapType.standard
        
        // 2)
        let location = CLLocationCoordinate2D(latitude: lati,longitude: long)
        // 3)
        let span = MKCoordinateSpanMake(0.75, 0.75)
        let region = MKCoordinateRegion(center: location, span: span)
        map.setRegion(region, animated: true)
        
        // 4)
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = nam
        annotation.subtitle = add
        annotation.index(ofAccessibilityElement: 1)
        map.addAnnotation(annotation)
  
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
