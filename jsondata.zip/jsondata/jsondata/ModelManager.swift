//
//  ModelManager.swift
//  SwiftDemoApp
//
//  Created by agile on 18/06/16.
//  Copyright © 2016 agile. All rights reserved.
//

import UIKit

let sharedInstance = ModelManager()

class ModelManager: NSObject
{
    
    var database:FMDatabase? = nil
    
    
    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            
            let fileURL = documentsURL.appendingPathComponent("Students.sqlite" as String)
            
            sharedInstance.database = FMDatabase(path: fileURL.path)
            
            
        }
        
        return sharedInstance
    }
    
    func InsertData(name:String,lat:Bool,lng:Bool) -> Bool
    {
        
        sharedInstance.database!.open()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO student (name,lat,lng) VALUES (?, ?,?)", withArgumentsIn: [name,lat,lng]);
        
        print(sharedInstance.database!.lastErrorMessage())
        
        sharedInstance.database!.close()
        
        return isInserted
    }
  /*
    func UpdateData(name:String,marks:String,rollNo:Int) -> Bool
    {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE Tbluser SET firstName=?, marks=? WHERE id=?", withArgumentsIn: [name, marks, rollNo])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    func getAllData() -> NSMutableArray
    {
        sharedInstance.database!.open()
        
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM Tbluser", withArgumentsIn: nil)
        
        let marrStudentInfo : NSMutableArray = NSMutableArray()
        
        if (resultSet != nil)
        {
            while resultSet.next()
            {
                let studentInfo : NSMutableDictionary = NSMutableDictionary()
                
                studentInfo.setValue(resultSet.string(forColumn: "firstName"), forKey: "firstName")
                
                
                studentInfo.setValue(resultSet.string(forColumn: "marks"), forKey: "Marks")
                
                let studentId:Int = Int(resultSet.int(forColumn: "id"))
                
                studentInfo.setValue(studentId, forKey: "RollNo")
                
                
                
                /*
                 studentInfo.RollNo = resultSet.stringForColumn("RollNo")
                 studentInfo.Name = resultSet.stringForColumn("Name")
                 studentInfo.Marks = resultSet.stringForColumn("Marks")
                 */
                marrStudentInfo.add(studentInfo)
            }
        }
        sharedInstance.database!.close()
        return marrStudentInfo
        
    }
    
    func DeleteRecord(rollNo:Int) -> Bool
    {
        sharedInstance.database!.open()
        
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM Tbluser WHERE id=?", withArgumentsIn: [rollNo])
        
        sharedInstance.database!.close()
        
        return isDeleted
    }

    */

    
    
   
}
