//
//  tableViewController.swift
//  jsondata
//
//  Created by Akshay on 02/06/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class tableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var dictt = NSDictionary()
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
       

        // Do any additional setup after loading the view.
    }
  /*
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return String(section)
    }
    */
   // func numberOfSections(in tableView: UITableView) -> Int {
  //      return ((dictt.object(forKey: "response") as!NSDictionary).object(forKey: "venues") as! NSArray).count
    //}
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       // return ((dictt.object(forKey: "response") as!NSDictionary).object(forKey: "venues") as! NSArray).count
       
        let response = dictt.object(forKey: "response") as!NSDictionary
        let venus = response.object(forKey: "venues") as! NSArray
        
        return venus.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        
                        let response = dictt.object(forKey: "response") as!NSDictionary
                       let venus = response.object(forKey: "venues") as! NSArray
        
                        let index0 = venus.object(at: indexPath.row) as! NSDictionary
        
                        let name = index0.object(forKey: "name")
        
                        let location = index0.object(forKey: "location") as! NSDictionary
        
        
                        let lat = location.object(forKey: "lat")
                        let lng = location.object(forKey: "lng")
        print(name)
        print(lat)
        print(lng)
        
        cell.lbllat.text = name as? String
        
        // cell.lbllat.text = String(describing: lat!)
        //cell.lbllng.text = String(describing: lng!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let mapVC = storyboard.instantiateViewController(withIdentifier: "mapViewController") as! mapViewController
        
    //    secondVC.images = UIImage(named: array[indexPath.row])!
     //   secondVC.text = array[indexPath.row]
        
        let response = dictt.object(forKey: "response") as!NSDictionary
        let venus = response.object(forKey: "venues") as! NSArray
        
        let index0 = venus.object(at: indexPath.row) as! NSDictionary
        
        let name = index0.object(forKey: "name")
        
        let location = index0.object(forKey: "location") as! NSDictionary
        
        let lat = location.object(forKey: "lat")
        let lng = location.object(forKey: "lng")
        let address = location.object(forKey: "address")
    
        
        mapVC.lati = lat as! Double
        mapVC.long = lng as! Double
        mapVC.nam = name as! String
        mapVC.add = address as! String
        
        
        
        let isInserted = ModelManager.getInstance().InsertData(name: name as! String, lat: (lat != nil), lng: (lng != nil))
        
        
        print("Inserted Value = \(isInserted)")

        
        
        self.navigationController?.pushViewController(mapVC, animated: true)

    }
 

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
