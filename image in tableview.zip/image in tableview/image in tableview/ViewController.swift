//
//  ViewController.swift
//  image in tableview
//
//  Created by Akshay on 4/19/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    let gujarat:[String] = ["ahmedabad1","Surat1","porbandar1"]
    let maharastra:[String] = ["mumbai1","pune1","nasik1"]
    let rajasthan:[String] = ["jaipur1","udaipur1","ajmer1"]
    
    
    
    
  let state = NSMutableArray()
    
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
            
            state.add(gujarat)
            state.add(maharastra)
            state.add(rajasthan)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0
        {
            return gujarat.count
        }else if section == 1
        {
            return maharastra.count
        }else
        {
            return rajasthan.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        if indexPath.section == 0{
            cell.imageView?.image = UIImage(named: gujarat[indexPath.row])
            cell.textLabel?.text = gujarat[indexPath.row]
        }else if indexPath.section == 1{
            cell.imageView?.image = UIImage(named: maharastra[indexPath.row])
            cell.textLabel?.text = maharastra[indexPath.row]
        }else{
            cell.imageView?.image = UIImage(named: rajasthan[indexPath.row])
            cell.textLabel?.text = rajasthan[indexPath.row]
        }
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return state.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0
        {
            return "gujarat"
        }else if section == 1
        {
            return "maharastra"
        }else{
            return "rajasthan"
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondVC = storyboard.instantiateViewController(withIdentifier:"secondViewController" ) as! secondViewController
        
    if indexPath.section == 0{
        secondVC.transimage =  UIImage(named: gujarat[indexPath.row])!
        secondVC.transtext = gujarat[indexPath.row]
    }else if indexPath.section == 1{
        secondVC.transimage =  UIImage(named: maharastra[indexPath.row])!
        secondVC.transtext = maharastra[indexPath.row]
    }else if indexPath.section == 2{
        secondVC.transimage =  UIImage(named: rajasthan[indexPath.row])!
        secondVC.transtext = rajasthan[indexPath.row]
    }
        
        self.navigationController?.pushViewController(secondVC, animated: true)
}
 
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
}
