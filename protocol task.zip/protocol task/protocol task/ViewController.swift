//
//  ViewController.swift
//  protocol task
//
//  Created by Akshay on 5/18/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,myFirstProtloco {
   
    
    @IBOutlet var tblList: UITableView!
    var count = Int()
    
    let players = NSMutableArray()
    
    let player1 = NSMutableDictionary()
    let player2 = NSMutableDictionary()
    let player3 = NSMutableDictionary()
    
    let userimage:[String] = ["img1","img2","img3"]
   // cell.imageView?.image = UIImage(named: maharastra[indexPath.row])
    
    
    var selectedIndex:Int = -1
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        player1.setValue("akshay", forKey:"fname")
        player1.setValue("patel", forKey: "lname")
        player1.setValue("21", forKey: "age")
        player1.setValue("0", forKey: "likes")
        
        
        player2.setValue("vishal", forKey:"fname")
        player2.setValue("sanghani", forKey: "lname")
        player2.setValue("21", forKey: "age")
        player2.setValue("0", forKey: "likes")
        
        player3.setValue("mayank", forKey:"fname")
        player3.setValue("prajapati", forKey: "lname")
        player3.setValue("21", forKey: "age")
        player3.setValue("0", forKey: "likes")
        
        
        
        players.add(player1)
        players.add(player2)
        players.add(player3)
        
     
    }
    
    //MARK: - Tableview delegate and DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return players.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        
         let arr1 = (players[indexPath.row] as! NSMutableDictionary)
        cell.lblfname.text = arr1.value(forKey: "fname") as? String
        
        
        
        
        
  
        cell.lblfname.text = ((players[indexPath.row] as! NSMutableDictionary).value(forKey: "fname") as! String)
        cell.lbllname.text = ((players[indexPath.row] as! NSMutableDictionary).value(forKey: "lname") as! String)
        cell.imguser.image = UIImage(named: userimage[indexPath.row])
        cell.lbllike.text = ((players[indexPath.row] as! NSMutableDictionary).value(forKey: "likes") as! String)
    
        return cell

    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex = indexPath.row
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondVC = storyboard.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
           
     secondVC.dic = players[indexPath.row] as! NSMutableDictionary
    secondVC.img = UIImage(named: userimage[indexPath.row])!
        secondVC.cou = count
        secondVC.delegate = self
        
      //  secondVC.transimage =  UIImage(named: gujarat[indexPath.row])!
        self.navigationController?.pushViewController(secondVC, animated: true)
    
    
    }

    
    func helloWorld(value: Int) {
        
        
        let dic = players.object(at: selectedIndex) as? NSDictionary
        
        let getLikeCount = dic?.object(forKey: "likes") as? String
        
        let totalCount = Int(getLikeCount!)! + 1
        
       // getLikeCount = getLikeCount! + 1
        
        
        let addCount = String(format: "%d", totalCount)
        
        dic?.setValue(addCount, forKey: "likes")
        
        players.replaceObject(at: selectedIndex, with: dic!)
        
        tblList.reloadData()
        
          count += 1
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

