//
//  TableViewCell.swift
//  protocol task
//
//  Created by Akshay on 5/18/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var lblfname: UILabel!
    @IBOutlet weak var lbllname: UILabel!
    
    @IBOutlet weak var lbllike: UILabel!
    
    @IBOutlet weak var lbldislike: UILabel!
    
    @IBOutlet weak var imguser: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
