//
//  secondViewController.swift
//  protocol task
//
//  Created by Akshay on 5/18/17.
//  Copyright © 2017 Akshay. All rights reserved.
//

import UIKit
protocol myFirstProtloco {
    func helloWorld(value:Int)
}



class secondViewController: UIViewController {
    
    var cou = Int()
    var delegate: myFirstProtloco?

    
    var dic = NSMutableDictionary()
    var img = UIImage()
    
    
    @IBOutlet weak var imagess: UIImageView!
    
    @IBOutlet weak var lblfname: UILabel!
    
    @IBOutlet weak var lbllname: UILabel!
    
    @IBOutlet weak var lblage: UILabel!
   
    @IBAction func btndislike(_ sender: UIButton) {
       
        
    }
    
    @IBAction func btnlike(_ sender: UIButton) {
        cou += 1
        delegate?.helloWorld(value:cou)
        
        print(cou)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(dic)
        
        lblfname.text = dic.value(forKey: "fname") as? String
        lbllname.text = dic.value(forKey: "lname") as? String
        lblage.text = dic.value(forKey: "age") as? String
        imagess.image = img
        
        
        
     //   cell.lblfname.text = ((players[indexPath.row] as! NSMutableDictionary).value(forKey: "fname") as! String)
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
