//
//  ViewController.swift
//  ProtocolLearning
//
//  Created by agilepc-140 on 17/05/17.
//  Copyright © 2017 Ballu. All rights reserved.
//

import UIKit

class ViewController: UIViewController,myFirstProtocol {
    var abc: String = String()
    @IBOutlet weak var lblFirst: UILabel!
    
    @IBOutlet weak var txtFirst: UITextField!
    
    @IBOutlet weak var lbl2First: UILabel!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let nc = NotificationCenter.default
        
        nc.addObserver(self, selector: #selector(userLoggedIn) , name: NSNotification.Name(rawValue: str), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lbl2First.text = str
    }
    
    func userLoggedIn () {
        
        print("notification method is called")
    }

    @IBAction func btnNext(_ sender: UIButton) {
        let next = storyboard?.instantiateViewController(withIdentifier: "SecondViewController")as! SecondViewController
        next.delegate = self
        next.valueFirst = txtFirst.text!
        navigationController?.pushViewController(next, animated: true)
    }
    
    //Mark:- Protocol Method
    
    func helloWorld(value: String)
    {
        lblFirst.text  = value + " " + txtFirst.text!
    }

}

