//
//  ThirdViewController.swift
//  ProtocolLearning
//
//  Created by agilepc-140 on 17/05/17.
//  Copyright © 2017 Ballu. All rights reserved.
//

import UIKit
 var str = String()
class ThirdViewController: UIViewController {
   
    @IBOutlet weak var txtThird: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnThird(_ sender: UIButton) {
        str = txtThird.text!
    let nc = NotificationCenter.default
        nc.post(name: NSNotification.Name(rawValue: str), object: nil)
        navigationController?.popToRootViewController(animated: true)
  
    }
   

   

}
