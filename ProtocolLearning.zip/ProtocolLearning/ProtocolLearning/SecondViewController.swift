//
//  SecondViewController.swift
//  ProtocolLearning
//
//  Created by agilepc-140 on 17/05/17.
//  Copyright © 2017 Ballu. All rights reserved.
//

import UIKit
protocol myFirstProtocol {
    func helloWorld(value:String)
}

class SecondViewController: UIViewController {
   
    var delegate: myFirstProtocol?
    
    @IBOutlet weak var lblSecond: UILabel!
    var valueFirst = String()
    
    @IBOutlet weak var txtSecond: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        lblSecond.text = valueFirst
       // valueSecond = txtSecond.text!
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnHome(_ sender: UIButton)
    {
        delegate?.helloWorld(value: txtSecond.text!)
        let next = storyboard?.instantiateViewController(withIdentifier: "ThirdViewController")as! ThirdViewController
        navigationController?.pushViewController(next, animated: true)

        
      //  self.navigationController?.popViewController(animated: true)
        
    }
    

}
