//
//  ViewController.swift
//  AllControls
//
//  Created by agile-10 on 24/03/17.
//  Copyright © 2017 agile-10. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {

    
    @IBOutlet weak var stepper: UIStepper!
    
    @IBOutlet weak var slider: UISlider!
    
    
    @IBOutlet weak var segment1: UISegmentedControl!
    
    @IBOutlet weak var lblControlName: UILabel!
    
    @IBOutlet weak var lblStatename: UILabel!
    
    @IBOutlet weak var table: UITableView!
    
    
    var array = [String]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        array = ["one","two","three","four","five","six",
               "seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty"]
      
    }

    @IBAction func swOnOff(_ sender: UISwitch) {
        lblControlName.text = "Switch"
        if sender.isOn {
            sender.setOn(false, animated: true)
            lblStatename.text = "off"
            segment1.isEnabled = false
            stepper.isEnabled = false
            slider.isEnabled = false
            table.isHidden = true
        }
        else{
            sender.setOn(true, animated: true)
            table.reloadData()
            lblStatename.text = "on"
            segment1.isEnabled = true
             table.isHidden = false
            table.isEditing = true
            
        }
        
    }
    
    @IBAction func stprPlusMinus(_ sender: UIStepper) {
        lblStatename.text = String(sender.value)
        lblControlName.text = "stepper"
        
    }
    
    @IBAction func segmentControl(_ sender: UISegmentedControl) {
        
        
        lblControlName.text = "segmentControl"
        if sender.selectedSegmentIndex == 0{
            lblStatename.text = "5"
        }
       else if sender.selectedSegmentIndex == 1{
            lblStatename.text = "10"
        }
       else if sender.selectedSegmentIndex == 2{
            lblStatename.text = "15"
            }
       else {
            lblStatename.text = "20"
        }
        
            table.reloadData()

    
    }
        
    
    
    @IBAction func sliderFM(_ sender: UISlider) {
        lblControlName.text = "slider"
        lblStatename.text = String(sender.value)
        
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if segment1.selectedSegmentIndex == 0
        {
            return 5
        }
      else if segment1.selectedSegmentIndex == 1
        {
            return 10
        }
      else if segment1.selectedSegmentIndex == 2
        {
            return 15
        }
        return array.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! LblToPrint
           cell.lblArrayValueToPrint.text = array[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete{
        array.remove(at: indexPath.row)
        table.reloadData()
    }
    }
    
    
    

}

