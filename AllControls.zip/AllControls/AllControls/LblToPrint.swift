//
//  LblToPrint.swift
//  AllControls
//
//  Created by agile-10 on 24/03/17.
//  Copyright © 2017 agile-10. All rights reserved.
//

import UIKit

class LblToPrint: UITableViewCell {

    
    @IBOutlet weak var lblArrayValueToPrint: UILabel!
    
}
