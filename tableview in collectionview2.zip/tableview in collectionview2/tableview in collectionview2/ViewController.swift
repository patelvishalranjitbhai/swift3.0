//
//  ViewController.swift
//  tableview in collectionview2
//
//  Created by agile on 4/24/17.
//  Copyright © 2017 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource {
    
    let array : [String] = ["img1","img2","img3","img4","img5"]
       // let array = NSMutableArray()
    
    @IBOutlet weak var tableview: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
     
//        array.add(#imageLiteral(resourceName: "img1"))
//        array.add(#imageLiteral(resourceName: "img2"))
//        array.add(#imageLiteral(resourceName: "img3"))
//        array.add(#imageLiteral(resourceName: "img4"))
//        array.add(#imageLiteral(resourceName: "img5"))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell1 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
      
       cell1.image.image = UIImage(named: array[indexPath.row])
         cell1.label.text = array[indexPath.row]
        
//        cell1.image.image = array[indexPath.row] as? UIImage
  //      cell1.label.text = array[indexPath.row] as? String
       
        return cell1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       return array.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondVC = storyboard.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController

        
        self.navigationController?.pushViewController(secondVC, animated: true)
        
        
    }
    
    
}

