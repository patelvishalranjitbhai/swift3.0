//
//  secondViewController.swift
//  tableview in collectionview2
//
//  Created by agile on 4/24/17.
//  Copyright © 2017 agile. All rights reserved.
//

import UIKit

class secondViewController: UIViewController {

    var images = String()
    
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var lblname: UILabel!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
