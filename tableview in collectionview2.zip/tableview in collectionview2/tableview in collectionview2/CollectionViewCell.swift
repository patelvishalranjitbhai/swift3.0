//
//  CollectionViewCell.swift
//  tableview in collectionview2
//
//  Created by agile on 4/24/17.
//  Copyright © 2017 agile. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var image: UIImageView!
    
    
}
